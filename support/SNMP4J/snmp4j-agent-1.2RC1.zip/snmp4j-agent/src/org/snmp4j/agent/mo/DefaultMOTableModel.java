/*_############################################################################
  _## 
  _##  SNMP4J-Agent - DefaultMOTableModel.java  
  _## 
  _##  Copyright (C) 2005-2008  Frank Fock (SNMP4J.org)
  _##  
  _##  Licensed under the Apache License, Version 2.0 (the "License");
  _##  you may not use this file except in compliance with the License.
  _##  You may obtain a copy of the License at
  _##  
  _##      http://www.apache.org/licenses/LICENSE-2.0
  _##  
  _##  Unless required by applicable law or agreed to in writing, software
  _##  distributed under the License is distributed on an "AS IS" BASIS,
  _##  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  _##  See the License for the specific language governing permissions and
  _##  limitations under the License.
  _##  
  _##########################################################################*/


package org.snmp4j.agent.mo;

import java.util.TreeMap;
import java.util.Collections;
import java.util.SortedMap;
import org.snmp4j.smi.OID;
import java.util.Iterator;

public class DefaultMOTableModel implements MOTableModel {

  protected SortedMap rows = Collections.synchronizedSortedMap(new TreeMap());
  protected int columnCount = 0;

  public DefaultMOTableModel() {
  }

  public synchronized MOTableRow addRow(MOTableRow row) {
    this.columnCount = Math.max(row.size(), columnCount);
    return (MOTableRow) rows.put(row.getIndex(), row);
  }

  public int getColumnCount() {
    return columnCount;
  }

  public int getRowCount() {
    return rows.size();
  }

  public synchronized MOTableRow getRow(OID index) {
    return (MOTableRow) rows.get(index);
  }

  public synchronized  OID firstIndex() {
    if (rows.size() > 0) {
      return (OID) rows.firstKey();
    }
    return null;
  }

  public synchronized Iterator iterator() {
    return rows.values().iterator();
  }

  public synchronized MOTableRow firstRow() {
    OID index = firstIndex();
    if (index != null) {
      return (MOTableRow) rows.get(index);
    }
    return null;
  }

  public synchronized OID lastIndex() {
    if (rows.size() > 0) {
      return (OID) rows.lastKey();
    }
    return null;
  }

  public synchronized MOTableRow lastRow() {
    OID index = lastIndex();
    if (index != null) {
      return (MOTableRow) rows.get(index);
    }
    return null;
  }

  public boolean containsRow(OID index) {
    return rows.containsKey(index);
  }

  public synchronized Iterator tailIterator(OID lowerBound) {
    if (lowerBound == null) {
      return iterator();
    }
    return rows.tailMap(lowerBound).values().iterator();
  }
}
