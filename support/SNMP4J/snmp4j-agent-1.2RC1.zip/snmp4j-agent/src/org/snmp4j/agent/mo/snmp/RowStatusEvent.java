/*_############################################################################
  _## 
  _##  SNMP4J-Agent - RowStatusEvent.java  
  _## 
  _##  Copyright (C) 2005-2008  Frank Fock (SNMP4J.org)
  _##  
  _##  Licensed under the Apache License, Version 2.0 (the "License");
  _##  you may not use this file except in compliance with the License.
  _##  You may obtain a copy of the License at
  _##  
  _##      http://www.apache.org/licenses/LICENSE-2.0
  _##  
  _##  Unless required by applicable law or agreed to in writing, software
  _##  distributed under the License is distributed on an "AS IS" BASIS,
  _##  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  _##  See the License for the specific language governing permissions and
  _##  limitations under the License.
  _##  
  _##########################################################################*/


package org.snmp4j.agent.mo.snmp;

import java.util.*;

import org.snmp4j.agent.mo.*;
import org.snmp4j.PDU;

public class RowStatusEvent extends DeniableEventObject {

//  private static final long serialVersionUID = 8808826350825049569L;

  private MOTable table;
  private MOTableRow row;
  private MOTableRow changeSet;
  private int oldStatus;
  private int newStatus;

  public RowStatusEvent(Object source,
                        MOTable table, MOTableRow row, MOTableRow changeSet,
                        int oldStatus, int newStatus) {
    this(source, table, row, changeSet, oldStatus, newStatus, false);
  }

  public RowStatusEvent(Object source,
                        MOTable table, MOTableRow row, MOTableRow changeSet,
                        int oldStatus, int newStatus, boolean deniable) {
    super(source, deniable);
    this.table = table;
    this.row = row;
    this.changeSet = changeSet;
    this.oldStatus = oldStatus;
    this.newStatus = newStatus;
  }

  public int getNewStatus() {
    return newStatus;
  }

  public int getOldStatus() {
    return oldStatus;
  }

  public MOTableRow getRow() {
    return row;
  }

  public MOTable getTable() {
    return table;
  }

  public MOTableRow getChangeSet() {
    return changeSet;
  }

  /**
   * Checks whether the row event represents an activation of a row.
   * To distinguish between a committing and a preparing row status event,
   * use {@link #isDeniable()}. If that method returns <code>true</code>,
   * then the event is fired on behalf of the preparation phase.
   * @return
   *    <code>true</code> if the new row status is createAndGo(4) or active(1)
   *    and the old status is not active(1).
   */
  public boolean isRowActivated() {
    return (((getNewStatus() == RowStatus.createAndGo) ||
             (getNewStatus() == RowStatus.active)) &&
            (getOldStatus() != RowStatus.active));
  }

  /**
   * Checks whether the row event represents a deactivation of a row.
   * To distinguish between a committing and a preparing row status event,
   * use {@link #isDeniable()}. If that method returns <code>true</code>,
   * then the event is fired on behalf the preparation phase.
   * @return
   *    <code>true</code> if the new row status is destroy(6) or notInService(2)
   *    and the old status is active(1).
   */
  public boolean isRowDeactivated() {
    return (((getNewStatus() == RowStatus.destroy) ||
             (getNewStatus() == RowStatus.notInService)) &&
            (getOldStatus() == RowStatus.active));
  }

}
