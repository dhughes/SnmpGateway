/*_############################################################################
  _##
  _##  SNMP4J-Agent - AgentConfigManager.java
  _##
  _##  Copyright (C) 2005-2008  Frank Fock (SNMP4J.org)
  _##
  _##  Licensed under the Apache License, Version 2.0 (the "License");
  _##  you may not use this file except in compliance with the License.
  _##  You may obtain a copy of the License at
  _##
  _##      http://www.apache.org/licenses/LICENSE-2.0
  _##
  _##  Unless required by applicable law or agreed to in writing, software
  _##  distributed under the License is distributed on an "AS IS" BASIS,
  _##  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  _##  See the License for the specific language governing permissions and
  _##  limitations under the License.
  _##
  _##########################################################################*/

package org.snmp4j.agent;

import java.io.*;
import java.util.*;

import org.snmp4j.*;
import org.snmp4j.agent.cfg.*;
import org.snmp4j.agent.io.*;
import org.snmp4j.agent.mo.snmp.*;
import org.snmp4j.agent.mo.snmp4j.*;
import org.snmp4j.agent.security.*;
import org.snmp4j.agent.version.*;
import org.snmp4j.log.*;
import org.snmp4j.mp.*;
import org.snmp4j.security.*;
import org.snmp4j.smi.*;
import org.snmp4j.util.*;

/**
 * The <code>AgentConfigManager</code> is the main component of a SNMP4J-Agent.
 * It puts together agent configuration and agent components like command
 * processor, message dispatcher, managed objects and server, USM, VACM, etc.
 *
 * @author Frank Fock
 * @version 1.2
 * @since 1.2
 */
public class AgentConfigManager implements Runnable {

  private static final LogAdapter logger =
      LogFactory.getLogger(AgentConfigManager.class);

  public static final int STATE_CREATED = 0;
  public static final int STATE_INITIALIZED = 10;
  public static final int STATE_CONFIGURED = 20;
  public static final int STATE_RESTORED = 30;
  public static final int STATE_SUSPENDED = 35;
  public static final int STATE_RUNNING = 40;
  public static final int STATE_UNSAVED_CHANGES = 45;
  public static final int STATE_SAVED = 50;
  public static final int STATE_SHUTDOWN = -1;

  protected CommandProcessor agent;
  protected WorkerPool workerPool;

  protected VACM vacm;
  protected USM usm;
  protected MOServer[] servers;
  protected Session session;
  protected MessageDispatcher dispatcher;
  protected OctetString engineID;
  protected ProxyForwarder proxyForwarder;
  protected NotificationOriginator notificationOriginator;

  protected MOInput configuration;
  protected MOPersistenceProvider persistenceProvider;
  protected int persistenceImportMode = ImportModes.UPDATE_CREATE;

  protected EngineBootsProvider engineBootsProvider;

  // mandatory standard MIBs
  protected SNMPv2MIB snmpv2MIB;
  protected SnmpTargetMIB targetMIB;
  protected SnmpCommunityMIB communityMIB;
  protected SnmpNotificationMIB notificationMIB;
  protected SnmpFrameworkMIB frameworkMIB;
  protected UsmMIB usmMIB;
  protected VacmMIB vacmMIB;

  // optional standard MIBs
  protected SnmpProxyMIB proxyMIB;

  // optional SNMP4J MIBs
  protected Snmp4jLogMib snmp4jLogMIB;
  protected Snmp4jConfigMib snmp4jConfigMIB;

  protected OctetString sysDescr =
      new OctetString("SNMP4J-Agent "+
                      VersionInfo.getVersion()+" [" +
                      org.snmp4j.version.VersionInfo.getVersion()+"]"+
                      " - "+System.getProperty("os.name","")+
                      " - "+System.getProperty("os.arch")+
                      " - "+System.getProperty("os.version"));
  protected OID sysOID = new OID("1.3.6.1.4.1.4976.10");
  protected Integer32 sysServices = new Integer32(72);

  protected AgentState runState = new AgentState();

  /**
   * Creates a SNMP agent configuration which can be run by calling
   * {@link #run()} later.
   *
   * @param agentsOwnEngineID
   *    the authoritative engine ID of the agent.
   * @param messageDispatcher
   *    the MessageDispatcher to use. The message dispatcher must be configured
   *    outside, i.e. transport mappings have to be added before this
   *    constructor is being called.
   * @param vacm
   *    a view access control model. Typically, this parameter is set to
   *    <code>null</code> to use the default VACM associated with the
   *    <code>VacmMIB</code>.
   * @param moServers
   *    the managed object server(s) that server the managed objects available
   *    to this agent.
   * @param workerPool
   *    the <code>WorkerPool</code> to be used to process incoming request.
   * @param configuration
   *    a <code>MOInput</code> that contains serialized ManagedObject
   *    information with the agent's configuration or <code>null</code>
   *    otherwise.
   * @param persistenceProvider
   *    the primary <code>MOPersistenceProvider</code> to be used to load
   *    and store persistent MOs.
   * @param engineBootsProvider
   *    the provider of engine boots counter.
   */
  public AgentConfigManager(OctetString agentsOwnEngineID,
                            MessageDispatcher messageDispatcher,
                            VACM vacm,
                            MOServer[] moServers,
                            WorkerPool workerPool,
                            MOInput configuration,
                            MOPersistenceProvider persistenceProvider,
                            EngineBootsProvider engineBootsProvider) {
    this.engineID = agentsOwnEngineID;
    this.dispatcher = messageDispatcher;
    this.vacm = vacm;
    this.servers = moServers;
    this.workerPool = workerPool;
    this.configuration = configuration;
    this.engineBootsProvider = engineBootsProvider;
    this.persistenceProvider = persistenceProvider;
  }

  /**
   * Initializes, configures, restores agent state, and then launches the
   * SNMP agent depending on its current run state. For example, if
   * {@link #initialize()} has not yet been called it will be called before
   * the agent is being configured in the next step.
   * <p>
   * See also {@link #initialize()}, {@link #configure()},
   * {@link #restoreState()}, and {@link #launch()}.
   */
  public void run() {
    if (runState.getState() < STATE_INITIALIZED) {
      initialize();
    }
    if (runState.getState() < STATE_CONFIGURED) {
      configure();
    }
    if (runState.getState() < STATE_RESTORED) {
      restoreState();
    }
    if (runState.getState() < STATE_RUNNING) {
      launch();
    }
  }

  /**
   * Launch the agent.
   */
  protected void launch() {
    dispatcher.addCommandResponder(agent);
    registerTransportMappings();
  }

  /**
   * Continues processing of SNMP requests by coupling message dispatcher and
   * agent.
   */
  public void continueProcessing() {
    if (runState.getState() < STATE_RUNNING) {
      dispatcher.removeCommandResponder(agent);
      dispatcher.addCommandResponder(agent);
      runState.setState(STATE_RUNNING);
    }
  }

  /**
   * Suspends processing of SNMP requests. This call decouples message
   * dispatcher and agent. All transport mappings remain unchanged and thus
   * all ports remain opened.
   */
  public void suspendProcessing() {
    dispatcher.removeCommandResponder(agent);
    runState.setState(STATE_SUSPENDED);
  }

  /**
   * Shutdown the agent by closing the internal SNMP session - including the
   * transport mappings provided through the configured
   * {@link MessageDispatcher} and then store the agent state to persistent
   * storage (if available).
   */
  public void shutdown() {
    try {
      session.close();
    }
    catch (IOException ex) {
      logger.warn("Failed to close SNMP session: "+ex.getMessage());
    }
    saveState();
    runState.setState(STATE_SHUTDOWN);
  }

  /**
   * Registers a shutdown hook <code>Thread</code> at the {@link Runtime}
   * instance.
   */
  public void registerShutdownHook() {
    Runtime.getRuntime().addShutdownHook(new Thread() {
      public void run() {
        shutdown();
      }
    });
  }

  public void initSnmp4jLogMIB() {
    snmp4jLogMIB = new Snmp4jLogMib();
  }

  public void initSnmp4jConfigMIB(MOPersistenceProvider[] persistenceProvider) {
    snmp4jConfigMIB = new Snmp4jConfigMib(snmpv2MIB.getSysUpTime());
    snmp4jConfigMIB.setSnmpCommunityMIB(communityMIB);
    if (this.persistenceProvider != null) {
      snmp4jConfigMIB.setPrimaryProvider(this.persistenceProvider);
    }
    if (persistenceProvider != null) {
      for (int i = 0; i < persistenceProvider.length; i++) {
        if (persistenceProvider[i] != this.persistenceProvider) {
          snmp4jConfigMIB.addPersistenceProvider(persistenceProvider[i]);
        }
      }
    }
  }

  protected void initSecurityModels(EngineBootsProvider engineBootsProvider) {
    usm = createUSM();
    SecurityModels.getInstance().addSecurityModel(usm);
    frameworkMIB = new SnmpFrameworkMIB(usm, dispatcher.getTransportMappings());
  }

  protected void initMessageDispatcherWithMPs(MessageDispatcher mp) {
    mp.addMessageProcessingModel(new MPv1());
    mp.addMessageProcessingModel(new MPv2c());
    MPv3 mpv3 = new MPv3(agent.getContextEngineID().getValue());
    mp.addMessageProcessingModel(mpv3);
  }

  protected void registerTransportMappings() {
    ArrayList l = new ArrayList(dispatcher.getTransportMappings());
    for (Iterator it = l.iterator(); it.hasNext();) {
      TransportMapping tm = (TransportMapping) it.next();
      tm.removeTransportListener(dispatcher);
      tm.addTransportListener(dispatcher);
    }
  }

  /**
   * Save the state of the agent persistently - if necessary persistent
   * storage is available.
   */
  public void saveState() {
    if (persistenceProvider != null) {
      try {
        persistenceProvider.store(persistenceProvider.getDefaultURI());
        runState.advanceState(STATE_SAVED);
      }
      catch (IOException ex) {
        throw new RuntimeException("Failed to save agent state", ex);
      }
    }
  }

  /**
   * Restore a previously persistently saved state - if available.
   * @return
   *    <code>true</code> if the agent state could be restored successfully,
   *    <code>false</code> otherwise.
   */
  public boolean restoreState() {
    if (persistenceProvider != null) {
      try {
        persistenceProvider.restore(persistenceProvider.getDefaultURI(),
                                    persistenceImportMode);
        return true;
      }
      catch (IOException ex) {
        logger.warn("Failed to load agent state: "+ex.getMessage());
      }
    }
    return false;
  }

  /**
   * Configures components and managed objects.
   */
  public void configure() {
    if (configuration != null) {
      MOServerPersistence serverPersistence = new MOServerPersistence(servers);
      try {
        serverPersistence.loadData(configuration);
      }
      catch (IOException ex) {
        throw new RuntimeException("Failed to load agent configuration", ex);
      }
    }
  }

  protected void initMandatoryMIBs() {
    targetMIB = new SnmpTargetMIB(dispatcher);
    snmpv2MIB = new SNMPv2MIB(getSysDescr(), getSysOID(), getSysServices());
    notificationMIB = new SnmpNotificationMIB();
    vacmMIB = new VacmMIB(servers);
    usmMIB = new UsmMIB(usm, getSupportedSecurityProtocols());
    communityMIB = new SnmpCommunityMIB(targetMIB);
  }

  /**
   * Gets the set of security protocols supported by this agent configuration.
   *
   * @return
   *    {@link SecurityProtocols#getInstance()} by default after initialization
   *    by {@link SecurityProtocols#addDefaultProtocols()}.
   */
  protected SecurityProtocols getSupportedSecurityProtocols() {
    SecurityProtocols.getInstance().addDefaultProtocols();
    return SecurityProtocols.getInstance();
  }

  /**
   * Creates the USM used by this agent configuration.
   *
   * @return
   *    an USM initialized by the engine boots from the
   *    <code>engineBootsProvider</code> and <code>engineID</code>.
   */
  protected USM createUSM() {
    return new USM(getSupportedSecurityProtocols(), engineID,
                   engineBootsProvider.updateEngineBoots());
  }

  /**
   * Gets the system services ID which can be modified by altering its value.
   *
   * @return
   *    72 by default.
   */
  public Integer32 getSysServices() {
    return sysServices;
  }

  /**
   * Gets the system OID which can be modified by altering its value.
   *
   * @return
   *    an OID - by default the SNMP4J root OID is returned.
   */
  public OID getSysOID() {
    return sysOID;
  }

  /**
   * Returns the sysDescr.0 value for this agent which can be modified by
   * altering its value.
   *
   * @return
   *    an OctetString describing the node of the form
   *    <pre>SNMP4J-Agent version [SNMP4J-version] -
   *         <os.name> - <os.arch> - <os.version></pre>.
   */
  public OctetString getSysDescr() {
    return sysDescr;
  }

  /**
   * Gets the sysUpTime.0 instance for the default context.
   *
   * @return
   *    a <code>SysUpTime</code> instance.
   */
  public SysUpTime getSysUpTime() {
    return snmpv2MIB.getSysUpTime();
  }

  /**
   * Gets the notification originator of this agent configuration.
   * @return
   *    a <code>NotificationOriginator</code> instance.
   */
  public NotificationOriginator getNotificationOriginator() {
    return notificationOriginator;
  }

  /**
   * Sets the notification originator of this agent configuration.
   * @param notificationOriginator
   *    a <code>NotificationOriginator</code> instance.
   */
  public void setNotificationOriginator(NotificationOriginator notificationOriginator) {
    this.notificationOriginator = notificationOriginator;
    if (agent != null) {
      agent.setNotificationOriginator(notificationOriginator);
    }
  }

  public void initialize() {
    session = createSnmpSession(dispatcher);
    if (engineID == null) {
      engineID = new OctetString(MPv3.createLocalEngineID());
    }
    agent = createCommandProcessor(engineID);
    agent.setWorkerPool(workerPool);
    initSecurityModels(engineBootsProvider);
    initMessageDispatcherWithMPs(dispatcher);
    initMandatoryMIBs();
    // use VACM-MIB as VACM by default
    if (vacm == null) {
      vacm = vacmMIB;
    }
    agent.setVacm(vacm);
    for (int i=0; i<servers.length; i++) {
      agent.addMOServer(servers[i]);
    }
    agent.setCoexistenceProvider(communityMIB);
    if (notificationOriginator == null) {
      notificationOriginator = createNotificationOriginator();
    }
    agent.setNotificationOriginator(notificationOriginator);

    initOptionalyMIBs();

    try {
      registerMIBs(null);
    }
    catch (DuplicateRegistrationException drex) {
      logger.error("Duplicate MO registration: "+drex.getMessage(), drex);
    }
    runState.advanceState(STATE_INITIALIZED);
  }

  protected void initOptionalyMIBs() {
    initSnmp4jLogMIB();
    initSnmp4jConfigMIB(null);
  }

  /**
   * Register the initialized MIB modules in the specified context of the agent.
   * @param context
   *    the context to register the internal MIB modules. This should be
   *    <code>null</code> by default.
   * @throws DuplicateRegistrationException if some of the MIB modules
   * registration regions conflict with already registered regions.
   */
  protected void registerMIBs(OctetString context) throws
      DuplicateRegistrationException
  {
    MOServer server = agent.getServer(context);
    targetMIB.registerMOs(server, context);
    notificationMIB.registerMOs(server, context);
    vacmMIB.registerMOs(server, context);
    usmMIB.registerMOs(server, context);
    snmpv2MIB.registerMOs(server, context);
    frameworkMIB.registerMOs(server, context);
    communityMIB.registerMOs(server, context);
    if (snmp4jConfigMIB != null) {
      snmp4jLogMIB.registerMOs(server, context);
    }
    if (snmp4jConfigMIB != null) {
      snmp4jConfigMIB.registerMOs(server, context);
    }
    if (proxyMIB != null) {
      proxyMIB.registerMOs(server, context);
    }
  }

  /**
   * Unregister the initialized MIB modules from the default context of the
   * agent.
   * @param context
   *    the context where the MIB modules have been previously registered.
   */
  protected void unregisterMIBs(OctetString context) {
    MOServer server = agent.getServer(context);
    targetMIB.unregisterMOs(server, context);
    notificationMIB.unregisterMOs(server, context);
    vacmMIB.unregisterMOs(server, context);
    usmMIB.unregisterMOs(server, context);
    snmpv2MIB.unregisterMOs(server, context);
    frameworkMIB.unregisterMOs(server, context);
    communityMIB.unregisterMOs(server, context);
    snmp4jLogMIB.unregisterMOs(server, context);
    snmp4jConfigMIB.unregisterMOs(server, context);
    proxyMIB.unregisterMOs(server, context);
  }

  public void setupProxyForwarder() {
    proxyForwarder = createProxyForwarder(agent);
  }

  protected NotificationOriginator createNotificationOriginator() {
    return new NotificationOriginatorImpl(session, vacm,
                                          snmpv2MIB.getSysUpTime(),
                                          targetMIB, notificationMIB);
  }

  /**
   * Creates and registers the default proxy forwarder application
   * ({@link ProxyForwarderImpl}).
   * @param agent
   *    the command processor that uses the proxy forwarder.
   * @return
   *    a ProxyForwarder instance.
   */
  protected ProxyForwarder createProxyForwarder(CommandProcessor agent) {
    proxyMIB = new SnmpProxyMIB();
    ProxyForwarder proxyForwarder =
        new ProxyForwarderImpl(session, proxyMIB, targetMIB);
    agent.addProxyForwarder(proxyForwarder,
                            null, ProxyForwarder.PROXY_TYPE_ALL);
    ((ProxyForwarderImpl)proxyForwarder).addCounterListener(snmpv2MIB);
    return proxyForwarder;
  }


  /**
   * Creates the command processor.
   *
   * @param engineID
   *    the engine ID of the agent.
   * @return
   *    a new CommandProcessor instance.
   */
  protected CommandProcessor createCommandProcessor(OctetString engineID) {
    return new CommandProcessor(engineID);
  }

  /**
   * Creates the SNMP session to be used for this agent.
   *
   * @param dispatcher
   *    the message dispatcher to be associated with the session.
   * @return
   *    a SNMP session (a {@link Snmp} instance by default).
   */
  protected Session createSnmpSession(MessageDispatcher dispatcher) {
    return new Snmp(dispatcher);
  }

  public class AgentState {
    private int state = STATE_CREATED;

    public int getState() {
      return state;
    }

    void setState(int newState) {
      this.state = newState;
    }

    void advanceState(int newState) {
      if (state < newState) {
        state = newState;
      }
    }
  }
}
