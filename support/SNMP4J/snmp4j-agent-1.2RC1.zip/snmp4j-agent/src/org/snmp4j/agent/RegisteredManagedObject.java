package org.snmp4j.agent;

import org.snmp4j.smi.OID;

/**
 * A registered ManagedObject has an unique OID that has been registered
 * world-wide by a MIB module.
 *
 * @author Frank Fock
 * @version 1.2
 */
public interface RegisteredManagedObject extends ManagedObject {

  /**
   * Gets the unique object ID of the managed object.
   * @return
   *   an OID.
   */
  OID getID();
}
